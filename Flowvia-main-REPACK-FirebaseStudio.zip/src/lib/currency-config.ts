// src/lib/currency-config.ts
export const CURRENCY_DECIMALS: Record<string, number> = {
  "USD": 2,
  "AED": 2,
  "SAR": 2,
  "JOD": 3,
  "EGP": 2,
  "UZS": 0,
  "CNY": 2,
};
